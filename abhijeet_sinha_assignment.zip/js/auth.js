    // Your web app's Firebase configuration
    var firebaseConfig = {
        apiKey: "AIzaSyAJOZy_Hdo2Lh_v5FjH9X4nig9wkytXHwo",
        authDomain: "krishworks-fb.firebaseapp.com",
        databaseURL: "https://krishworks-fb.firebaseio.com",
        projectId: "krishworks-fb",
        storageBucket: "krishworks-fb.appspot.com",
        messagingSenderId: "446770225584",
        appId: "1:446770225584:web:b11d88d0101f46f08a3675"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
